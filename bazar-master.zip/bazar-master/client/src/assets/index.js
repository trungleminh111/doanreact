import logoDark from "./logoDark.png";
import logoLight from "./logoLight.png";
import cartImg from "./cart.png";
import paymentLogo from "./paymentLogo.png";
import googleLogo from "./googleLogo.png";
import githubLogo from "./githubLogo.png";

export { logoDark, logoLight, cartImg, paymentLogo, googleLogo, githubLogo };
